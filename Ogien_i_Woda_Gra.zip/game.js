
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

let fire = { x: 50, y: 300, color: "red" };
let water = { x: 150, y: 300, color: "blue" };

function drawPlayer(player) {
    ctx.fillStyle = player.color;
    ctx.fillRect(player.x, player.y, 30, 30);
}

function update() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    drawPlayer(fire);
    drawPlayer(water);
    requestAnimationFrame(update);
}

update();
