
const canvas = document.getElementById("tunnel");
const ctx = canvas.getContext("2d");

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

let angle = 0;
function draw() {
  ctx.fillStyle = "rgba(0, 0, 0, 0.1)";
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  const centerX = canvas.width / 2;
  const centerY = canvas.height / 2;
  const radius = 200;
  const lines = 30;

  for (let i = 0; i < lines; i++) {
    const a = angle + (i * Math.PI * 2) / lines;
    const x = centerX + Math.cos(a) * radius;
    const y = centerY + Math.sin(a) * radius;
    ctx.beginPath();
    ctx.moveTo(centerX, centerY);
    ctx.lineTo(x, y);
    ctx.strokeStyle = `hsl(${i * 12 + angle * 50}, 100%, 50%)`;
    ctx.stroke();
  }

  angle += 0.01;
  requestAnimationFrame(draw);
}
draw();
