
let coins = 100;
let workers = 0;

function updateDisplay() {
    document.getElementById('coins').innerText = coins;
    document.getElementById('workers').innerText = workers;
}

function earnCoins() {
    coins += 10;
    updateDisplay();
}

function hireWorker() {
    if (coins >= 50) {
        coins -= 50;
        workers += 1;
        updateDisplay();
    } else {
        alert("Za mało monet!");
    }
}

updateDisplay();
